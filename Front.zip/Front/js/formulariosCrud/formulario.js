import * as inputs from "./inputs.js"
export const crearFormularios = function(){
}