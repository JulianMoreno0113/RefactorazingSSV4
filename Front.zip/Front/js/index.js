import * as nav from "./Nav/nav.js"
const contenedorNav = document.querySelector(".contenedorNav");
contenedorNav.append(nav.crearNav());




 